CDS FIELD TOOLS 更新パッケージ
================================

今回の更新：
・トップページの防災単独カードを「FIELD TOOLS」2枚構成へ変更
  - 都城市 防災統合ビューア β
  - 都城市 くらしのおたすけマップ β
・F-03「暮らしの不便を、道具で」にも、くらしマップへのリンクを追加
・ナビの「防災β」を「ツールβ」に変更
・D-03 のタグを「GIS / 生活情報」に変更
・くらしのおたすけマップ専用ページを追加
・AEDの注意事項、β版・非網羅であることを専用ページに明記

GitHub Pagesへの配置：
1. ルートの index.html を、このパッケージの index.html に置き換える
2. tools/life-support フォルダを、そのまま CDS リポジトリの tools/ 配下に追加する

構成：
CDS/
├─ index.html                       ← 置き換え
└─ tools/
   ├─ disaster/                    ← 既存のまま
   │  ├─ index.html
   │  └─ map.html
   └─ life-support/                ← 今回追加
      ├─ index.html
      ├─ map.html
      └─ data.json

注意：
・tools/disaster は削除しないでください。
・くらしマップは公開情報から順次追加するβ版です。
・AEDの半透明ピンは概略位置です。
